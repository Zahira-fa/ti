package Exercices4;

public class LignePol {

    private Point[] sommets;
    private int nbsommets;

    public LignePol(int n) {
        this.sommets = new Point[n];
        this.nbsommets = sommets.length;

    }
    public LignePol(Point[] sommets) {
        this.sommets = sommets;
        this.nbsommets = sommets.length;
    }
    public Point getSommet(int i) {
        return sommets[i];
    }
    public void setSommet(int i, Point p) {
        sommets[i] = p;
    }
    public void homothetie(double k){
        for(int sommet = 0; sommet < sommets.length; sommet++)
        sommets[sommet].homothetie(k);
    }
    public void translation(double dx, double dy) {
        for(int sommet = 0; sommet < sommets.length; sommet++) {
            sommets[sommet].translation(dx,dy);
        }
    }
    public void rotation(double a) {
        for(int sommet = 0; sommet < sommets.length; sommet++)
            sommets[sommet].rotation(a);
    }

    public void tracer() {
        for(int sommet = 0 ; sommet < nbsommets; sommet++)
            if (sommet < nbsommets -1)
                tracerLigne(getSommet(sommet).x(),getSommet(sommet).y(),getSommet(sommet+1).x(),getSommet(sommet+1).y());
            else tracerLigne(getSommet(sommet).x(),getSommet(sommet).y(),getSommet(0).x(),getSommet(0).y());
    }
    public void tracerLigne(double x0 , double y0 , double x1 , double y1) {
        System.out.println("tracer de (" + x0 + "," + y0 + ") à (" + x1 + "," + y1 + ")");
    }
    public String toString() {
        String res = "";
        for (int i = 0; i < sommets.length; i++) {
            res = res + "\n" + getSommet(i);
        }
        return res;
    }
}
