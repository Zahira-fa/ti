package Exercices4;

public class Point {

    private double x ;
    private double y ;

    // Constructeur

    public Point(double x , double y){
        this.x=x;
        this.y=y;
    }

    public double x() {
        return x;
    }

    public double y() {
        return y;
    }

    public double r(){
        return Math.sqrt(Math.pow(x,2) +Math.pow(y,2));
    }

    public double t(){
        return Math.atan2(y,x) ;
    }

    public String toString(){
        return "("+x+","+y+")";
    }

    public boolean equals(Object o) {
        if (o == null) {
            return false;
        } else {
            if (o.getClass() != getClass()) {
                return false;
            }
            Point point = (Point) o;
            return point.x() == x() && point.y() == y();
        }
    }

    public void homothetie(double k){
        x *=k;
        y *=k;
    }

    public void translation(double dx , double dy){
        x +=dx;
        y +=dy;
    }

    public void rotation(double a) {
        x = r() ;
        y = t() +a ;
    }


}
