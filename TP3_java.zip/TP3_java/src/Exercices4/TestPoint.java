package Exercices4;
public class TestPoint {
    public static void main(String[] args) {


        Point point = new Point(1,3);
        Point point1 = new  Point(1,3);
        Point point2 = new  Point(2,4);
        System.out.println("   ---les points---");
        System.out.println("les cordonnes du point : "+point);
        System.out.println("les cordonnes du point1 : "+point1);
        System.out.println("les cordonnes du point2 : "+point2);

        System.out.println("Est ce que les points sont egaux :"+point.equals(point1));

        System.out.println("r ="+point.r()+"\nt = "+point.t());

        point.rotation(10);

        System.out.println("la rotation du point : "+point);

        point.translation(3,4);

        System.out.println("tanslation du point :"+point);

        point.homothetie(4);

        System.out.println("homothetie du point : "+point);

        LignePol sommets = new LignePol(3);
        sommets.setSommet(0,point);
        sommets.setSommet(1,point1);
        sommets.setSommet(2,point2);

        Point[] s = {new Point(3,4) , new Point(1,6), new Point(4,5)};

        LignePol sommet = new LignePol(s);

        System.out.println("   ---les points---  "+sommet);
        sommet.translation(1,2);
        System.out.println("   ---translation des points ---  "+sommet);
        sommet.homothetie(3);
        System.out.println("   ---homothetie des points ---  "+sommet);
        sommet.rotation(2);

        sommet.tracer();





    }
}
