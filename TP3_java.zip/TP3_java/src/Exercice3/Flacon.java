package Exercice3;

public class Flacon {

    private final float capacite ; // on ne peut pas changer la capacité d'un flacon a chaque fois
    private float volume ;
    private float concentration  ;
    private String etiquette ;

    //Constructeur

    public Flacon(String etiquette ,float capacite){
        this.etiquette = etiquette ;
        this.capacite = capacite ;
    }

    public void verser(float volumeSirop , float volumeEeau){

        concentration = (volumeSirop)/(volumeSirop + volumeEeau);
        volume = (volumeSirop + volumeEeau);
        if(capacite < volume) {
            System.out.println("Impossible de verser !!!");
        }
    }

    public void transvaser(Flacon autreFlacon ,float volume){


        if (this.capacite > (this.volume+volume) && autreFlacon.volume > 0) {
            autreFlacon.volume -= volume;
            this.volume += volume;
        }
        else System.out.println("Impossible de transvaser !!!");

    }


    public String toString(){
        return  "\t\t***Flacon***"+
                "\n\tEtiquette :"+etiquette+
                "\n\tVolume : "+volume+"ml"+
                "\n\tConcentration : "+concentration;
    }

}
