package Exercice3;

public class TestFlacon {
    public static void main(String[] args) {
        Flacon flacon = new Flacon("Text",1000);
        Flacon flacon1 = new Flacon("Text" , 1000);
        flacon.verser(10,900);
        flacon1.verser(20,100);
        flacon.transvaser(flacon1,10);
        System.out.println(flacon.toString());
        System.out.println(flacon1.toString());
    }
}
