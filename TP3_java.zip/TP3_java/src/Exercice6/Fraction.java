package Exercice6;

import java.math.BigInteger;

public class Fraction {

    private BigInteger num ;
    private BigInteger den ;

    //constructeur
    public Fraction(BigInteger num, BigInteger den) {
        this.num = num;
        this.den = den ;
    }

    public Fraction(int n , int d){
        this.num = BigInteger.valueOf(n); // Convertir du Int -> BigInterger
        this.den = BigInteger.valueOf(d);
    }

    public Fraction(int n){
        this.num = BigInteger.valueOf(n);
        this.den = BigInteger.ONE; // den !=0
    }
    // addition
    public Fraction add(Fraction f) {
        if (den.compareTo(f.den) == 0){
            return new Fraction(num.add(f.num), f.den) ;
        }
        else{
            return new Fraction(num.multiply(f.den).add(f.num.multiply(den)), den.multiply(f.den));
        }
    }
    //soustraction
    public Fraction sub(Fraction f) {
        if( den.compareTo(f.den) == 0 ){
            return new Fraction(num.subtract(f.num), f.den);
        } else {
            return new Fraction(num.multiply(f.den).subtract(f.num.multiply(den)), den.multiply(f.den));
        }
    }

    //multi plication
    public Fraction mult(Fraction f) {
        return new Fraction(num.multiply(f.num), den.multiply(f.den));
    }

    //division
    public Fraction divi(Fraction f) {
        return new Fraction(num.multiply(f.den), den.multiply(f.num));
    }

    public String toString(){
        return "("+num+"/"+den+")";
    }

    public double doubleValue() {
        return num.doubleValue() / den.doubleValue();
    }
}