package Exercice6;

import java.math.BigInteger;

public class TestFraction {
    public static void main(String[] args) {
        BigInteger bigInteger = new BigInteger("1234567890");
        BigInteger bigInteger2 = new BigInteger("9876543210");
        Fraction fraction1 = new Fraction(bigInteger, bigInteger2);
        Fraction fraction2 = new Fraction(6, 9);
        Fraction fraction3 = new Fraction(7);
        System.out.println("\t\t\t fractions");
        System.out.println("fraction 1 : " + fraction1);
        System.out.println("fraction 2 : " + fraction2);
        System.out.println("fraction 3 : " + fraction3);
        System.out.println("\n\t\t\tresultats des calculs");
        System.out.println("addition f1 + f2 : " + fraction1.add(fraction2));
        System.out.println("soustraction  f1 - f2 : " + fraction1.sub(fraction2));
        System.out.println("multiplication  f1 * f2 : " + fraction1.mult(fraction2));
        System.out.println("division  f1 / f2 : " + fraction1.divi(fraction2));
        System.out.println("\n\t\t\tvaleurs decimales ");
        System.out.println("fraction 1 :"+fraction1.doubleValue());
        System.out.println("fraction 2 :"+fraction2.doubleValue());
        System.out.println("fraction 3 :"+fraction3.doubleValue());

    }
}
