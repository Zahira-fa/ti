package Exercies5;

import Exercices4.Point;
import Exercies5.Rectangle;

public class TestRectangle {
    public static void main(String[] args) {

        Rectangle r1, r2;
        r1 = new Rectangle(1, 2, 3, 4);
        r2 = r1;
        System.out.println("r1: " + r1 + ", r2: " + r2);
        r1.coinNO = new Point(0, 0);
        System.out.println("r1: " + r1 + ", r2: " + r2);
        r1.coinSE.homothetie(2);
        System.out.println("r1: " + r1 + ", r2: " + r2);
    }
}
