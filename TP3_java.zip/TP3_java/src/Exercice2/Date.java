package Exercice2;


import java.util.Calendar;

public class Date {
    private int jour;
    private int mois;
    private int annee;
    private int jourSemaine;

    private static int jourSemaine(int jour, int mois, int annee){
        Calendar c = Calendar.getInstance();
        c.set(annee , mois -1 ,jour);
        return (c.get(Calendar.DAY_OF_WEEK)+ 5) % 7 ;
    }
    // Constructeur .
    public Date(int jour, int mois, int annee) {
        boolean dateInvalide = mois < 1 || mois > 12
                || jour < 1 || jour > 31
                || jour == 31 && (mois == 4 || mois == 6 || mois == 9 || mois == 11)
                || jour == 30 && mois == 2
                || jour == 29 && mois == 2 && annee % 4 != 0;
        if (dateInvalide) {
            System.out.println("Date Invalide");
        }
        this.jour = jour;
        this.mois = mois;
        this.annee = annee;
        this.jourSemaine = jourSemaine(jour , mois , annee);
    }

    // Acceseur .
    public int getJour() {

        return jour;
    }

    public int getMois() {
        return mois;
    }

    public int getAnnee() {

        return annee;
    }

    public int getJourSemaine() {

        return jourSemaine;
    }

    // tableau des noms des jours .

    private String[] nomsJ = { "Lundi", "Mardi", "Mercredi", "Jeudi","Vendredi", "Samedi", "Dimanche" };

    // tableau des noms des mois .

    private String[] nomsM = { "Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Decembre" };

    public String toString() {
        return nomsJ[jourSemaine] + " " + jour + " "
                + nomsM[mois - 1] + " " + annee;
    }


}