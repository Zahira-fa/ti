package Exercice2;

public class TestDate {
    public static void main(String[] args) {
        Date[] date = new Date[5] ;
        date[0] = new Date(9,1,2021);
        System.out.println(date[0].toString());
    }
}
