package Execice1;

public class TestArticle {
    public static void main(String[] args) {
        Article[] articles ;
        articles = new Article[10] ;
        articles[0] = new Article(1,"imprimante",10,100);
        articles[1] = new Article(2,"telephone",20,200);
        articles[2] = new Article(3,"PC",50,500);
        articles[3] = new Article(4,"camera",40,400);
        articles[4] = new Article(5,"casque",50,500);
        int  i ;
        articles[1].approvisionner(10);
        if (articles[1].vendre(80) == true) {
            System.out.println("la vente a eu lieu");
        }else System.out.println("la vente n'a pas eu lieu");
        System.out.println(        articles[0].equals(articles[1]));

        for (i=0 ; i<5 ; i++){
            System.out.println(articles[i].toString());
        }
    }
}
