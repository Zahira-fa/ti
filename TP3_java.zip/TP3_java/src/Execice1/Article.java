package Execice1;

public class Article {
    private long reference ;
    private String intitule ;
    private float prixHT ;
    private int quantiteEnStock ;

    //Constructeur .
    public Article(long reference, String intitule, float prixHT, int quantiteEnStock) {
        this.reference = reference;
        this.intitule = intitule;
        this.prixHT = prixHT;
        this.quantiteEnStock = quantiteEnStock;
    }
    // getter .
    public long getReference() {
        return reference;
    }

    public String getIntitule() {
        return intitule;
    }

    public int getQuantiteEnStock() {
        return quantiteEnStock;
    }

    //méthode pour augmenter la quantité disponible de l’article
    public void approvisionner(int nombreUnites) {
        quantiteEnStock += nombreUnites ;

    }

    public boolean vendre(int nombreUnites) {
        if (quantiteEnStock >= nombreUnites ) {
            quantiteEnStock -=nombreUnites ;
            return true;
        }
        else return false ;
    }

    public float getPrixHT() {
        return prixHT;
    }

    public float prixHT() {
        return this.prixHT() ;
    }

    public float prixTTC() {
        return (getPrixHT() + getPrixHT()*20/100) ;
    }

    public String toString() {
        return " --- Article ---" +
                "\n reference=" + getReference() +
                "\n intitule='" + getIntitule() +
                "\n prixHT=" + getPrixHT() +
                "\n quantiteEnStock=" + getQuantiteEnStock() +
                "\n prixTTC="+ prixTTC();
    }

    public boolean equals(Article unArticle){
        if(this.reference == unArticle.reference) return true ;
        else return false ;
    }
}
